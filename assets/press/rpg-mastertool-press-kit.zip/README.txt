RPG MasterTool press kit (Soheili Labs) for GM Craft Tavern.
Write-up, short/long descriptions, features and demo login: rpg-mastertool-write-up.md
Video: video/rpg-mastertool-introduction.mp4 (59 s, 1920x1080, narrated + captioned)
Screenshots: screenshots/ (real session, demo campaign "The Salt Verdict")
Logos: logo/
Contact: info@soheililabs.com
