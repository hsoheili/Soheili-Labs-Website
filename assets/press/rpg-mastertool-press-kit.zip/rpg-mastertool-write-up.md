# RPG MasterTool: press kit for GM Craft Tavern

Made by Soheili Labs (pronounced "soh-HAY-lee"). Web app: works on a phone,
tablet or laptop, nothing to install.

**Status:** free public beta. Free for Game Masters during the beta; players
never pay.

**Try it:** https://rpg.soheililabs.com/?from=gmcrafttavern
**Contact:** info@soheililabs.com

## Short description (about 50 words)

RPG MasterTool is a campaign operating system for tabletop Game Masters. Drop
in an encounter scaled to your party, run one shared turn order, let the
enemies roll their own attacks, and let players take their turns from their
own phones. Free for Game Masters during the beta; players never pay.

## Long description (about 150 words)

RPG MasterTool keeps the whole table in one place. The Game Master runs the
night from one screen: the party, quests, clocks and a live session timer. In
a fight, drop in a ready-made encounter at the difficulty you choose; it is
scaled to the size and level of your party and rolled into one shared turn
order. On Quick GM, enemies roll their own attacks and each result waits until
you close it. Short a player? Swing for that hero yourself. When a player holds
a sheet, the board waits for them, and they take the turn from their own
phone: their attack, their target, swing. Every swing lands in one feed the
whole table can see. Pick the system that fits your game, from 5e-compatible
to Weird West, and the sheets, enemies and attacks follow it. Free for Game
Masters during the beta; players never pay.

## Key features

- Shared turn order everyone at the table sees, on their own screen
- Encounter drop-in: eight ready-made scenarios, Easy to Deadly, scaled to the party
- Quick GM: enemies roll their own attacks; results wait for the GM
- Players take their own turns from their phones; the board waits for them
- "What just happened" feed of every swing, for the whole table
- Party HP, AC and conditions at a glance; quests, clocks and session timer
- Eight systems: 5e-compatible, Cyberpunk, Space opera, Investigative horror,
  Post-apocalyptic, Modern superhero, Weird West, system-agnostic
- Players join by invitation and see only what the GM chooses to show

## Demo login

Two ways in, neither needs anything from us:

1. **No account at all:** https://rpg.soheililabs.com/?try=1 ("Try it now, no
   sign-up"). You get a private table with the ready-made campaign "The Salt
   Verdict", kept for a week.
2. **Your own account:** create one at rpg.soheililabs.com, press New, and
   start "The Salt Verdict".

A shared reviewer login also exists: **demo@soheililabs.com**, a plain Game
Master account (not an admin) with "The Salt Verdict" already mid-fight. Its
password is not in this kit. It is kept on the server, readable by root only,
at /root/rpg-mastertool-secrets/demo-gm.password, and sent to a reviewer
directly. Before handing it out, reset the demo table on the VPS with:

    node scripts/seed-demo.mjs https://rpg.soheililabs.com

## What's in this kit

- video/rpg-mastertool-introduction.mp4: 59 seconds, 1920x1080, narrated and
  captioned. A Game Master running a fight in "The Salt Verdict".
- screenshots/: eight screens from a real session (see the file names)
- logo/: die mark, app icon, name lockups for dark and light, the website
  product icon, and the Soheili Labs mark
