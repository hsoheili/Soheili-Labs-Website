# RPG MasterTool: introduction video script

59 seconds, 1920x1080. Narrated (voice: Kokoro af_heart; "Soheili" voiced as "soh-HAY-lee"), with every line also on screen as a caption for muted autoplay. Every screen is a real capture of RPG MasterTool v82.170.0 running the demo campaign "The Salt Verdict".

## 1. 00.0s to 10.6s
- **Visual:** Soheili Labs mark, "presents", RPG MasterTool mark
- **On screen:** Free beta for Game Masters / RPG MasterTool / Run the table. Keep the fight moving.
- **Narration:** Soheili Labs builds focused software for small teams and the people who run them. This is RPG MasterTool, free for Game Masters during the beta.

## 2. 10.6s to 16.8s
- **Visual:** Screen: scene-dashboard.png
- **On screen:** Session night / The whole campaign on one screen. / Party, quests and clocks; Live session timer; Works on a laptop or a phone
- **Narration:** Run the night from one screen: the party, open quests, clocks, and a live session timer.

## 3. 16.8s to 24.7s
- **Visual:** Screen: scene-encounter.png
- **On screen:** Combat / Drop in a whole encounter. / Pick a scenario and a difficulty. It's scaled to your party and rolled into one turn order.
- **Narration:** Drop in an encounter at the difficulty you choose. It's scaled to your party and rolled straight into one shared turn order.

## 4. 24.7s to 31.9s
- **Visual:** Screen: scene-enemy.png
- **On screen:** Quick GM / Enemies roll for themselves. / Each result waits until you close it. Then you move the turn on.
- **Narration:** On Quick GM, the enemies roll their own attacks. Each result waits for you, then you move the turn on.

## 5. 31.9s to 37.5s
- **Visual:** Screen: scene-hero.png
- **On screen:** Short a player? / Swing for any hero. / Nobody playing a sheet tonight? Take the turn yourself.
- **Narration:** Short a player tonight? Pick an attack and a target, and swing for that hero yourself.

## 6. 37.5s to 42.2s
- **Visual:** Screen: scene-waiting.png
- **On screen:** Players at the table / The board waits for the player. / A hero someone plays is theirs to swing. Wait for them, or act for them.
- **Narration:** When a player holds the sheet, the board waits for them to take their turn.

## 7. 42.2s to 46.8s
- **Visual:** Two phones: the player's turn screen (Mace, target Dockhand 2, Swing) and the result, "Hit — 4 damage"
- **On screen:** On their phone / Players swing from their own phones. / Your turn, your attack, your target. Swing.
- **Narration:** And they take it from their own phone: their attack, their target, swing.

## 8. 46.8s to 50.9s
- **Visual:** Screen: scene-feed.png
- **On screen:** At the table / Every swing, for everybody. / One feed of what just happened, so the whole table follows the fight.
- **Narration:** Every swing lands in one feed the whole table can see.

## 9. 50.9s to 59.0s
- **Visual:** Both marks, closing card
- **On screen:** Free for Game Masters during the beta. / Players never pay. Nothing to install. / button: rpg.soheililabs.com
- **Narration:** Free for Game Masters during the beta, and players never pay. Try it at rpg.soheililabs.com.
